//this method  

public class FullName extends AddressBook {
  
  //declare variables
  private String firstName;
  private String lastName;
  
  public FullName() { //initialize info
    firstName = "";
    lastName = "";
  }
  
  public FullName(String fullFirst, String fullLast) { //take in info
    firstName = fullFirst;
    lastName = fullLast;
  }
  
  public String getFirstName() {
    return firstName; 
  }
  
  public String getLastName() {
    return lastName; 
  }
  
  //modifier methods, setter methods
  public void setFirstName(String f) {
    firstName = f; 
  }
  
  public void setLastName(String l) {
    lastName = l; 
  }
}