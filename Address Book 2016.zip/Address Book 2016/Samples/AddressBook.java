/* [AddressBook]
 * 
 * Name: Jacqueline Chung
 * Date: October 31-November 7, 2014
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

  public class AddressBook extends JFrame implements ActionListener{ 
    //Create some Panels
   JPanel pan1 = new JPanel();
   JPanel pan2 = new JPanel();
    
   //Create some GUI components
   //add 
   JTextField nameField = new JTextField(20);
   //add labels for names, address, phone number, email
   JLabel firstLabel = new JLabel("First Name: ", JLabel.RIGHT);   
   JLabel lastLabel = new JLabel("Last Name: ", JLabel.RIGHT);
   JLabel addressLabel = new JLabel("Address ", JLabel.RIGHT);
   JLabel phoneLabel = new JLabel("Phone: ", JLabel.RIGHT);
   JLabel emailLabel = new JLabel("Email: ", JLabel.RIGHT);
   //add buttons for add, delete, edit, and search
   JButton addButton = new JButton("Add");   
   JButton deleteButton = new JButton("Delete"); 
   JButton editButton = new JButton("Edit");
   JButton searchButton = new JButton("Search");

   // CONSTRUCTOR - Setup your GUI here
   public AddressBook() { 
      setTitle("Address Book (Jacqueline Chung)");    //Create a window with a title
      setSize(640, 480);           // set the window size
     
      // Create some Layouts
      GridLayout layout1 = new GridLayout(2,1);
      FlowLayout layout2 = new FlowLayout();
      
      // Set the frame and both panel layouts
      setLayout(layout1);
      pan1.setLayout(layout2);
      pan1.setLayout(layout2);
      
      // Add an action listener to the button, this allows the program to know if the button was pressed
      addButton.addActionListener(this);  
      deleteButton.addActionListener(this);  
      editButton.addActionListener(this);  
      searchButton.addActionListener(this);  
      
      // Add all the components to the first panel
      pan1.add(firstLabel);  // add the first name label 
      pan1.add(nameField); //add a text field for the user to right their first name
      pan1.add(lastLabel);  // add the last name label 
      pan1.add(nameField); //add a text field for the user to right their last name
      pan1.add(addressLabel);  // add the address label 
      pan1.add(nameField); //add a text field for the user to right their address
      pan1.add(phoneLabel);  // add the phone number label 
      pan1.add(nameField); //add a text field for the user to right their phone number
      pan1.add(emailLabel);  // add the first email address label 
      pan1.add(nameField); //add a text field for the user to right their email address
      // Add all the components to the second  panel
      pan2.add(addButton);//add a button to add contact
      pan2.add(deleteButton);//add a button to delete contact
      pan2.add(editButton);//add a button to edit contact
      pan2.add(searchButton);//add a button to search for contact
      
      // add the panels to the frame and display the window
      add(pan1);
      add(pan2);
      setVisible(true); 
    }
    
   // ACTION LISTENER - This method runs when an event occurs
   // Code in here only runs when a user interacts with a component
   // that has an action listener attached to it
   public void actionPerformed(ActionEvent event) {
   
     String command = event.getActionCommand();  //find out the name of the component
                                                 //that was used
   
     if (command.equals("OK")) {                 // if the OK button was pressed
       System.out.println("ok button pressed");  // display message in console(for testing)
       //System.out.println("Date:" + nameField.getText()); //get the info located in the field component
       //instructionsLabel.setText("Thank you " + nameField.getText() );            // change the label message to 'thank you'
     } // no other conditions 
         
   }
   
   //Main method
    public static void main(String[] args) {
      AddressBook frame1 = new AddressBook();  //Start the GUI
    }

}