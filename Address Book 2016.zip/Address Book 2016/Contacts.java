/* Name: Jacqueline Chung
 * Teacher: Mrs. Andrighetti
 * Date: January 7 - 18, 2016
 * Description:  
 */

public class Contacts {
  // class constants

  //constructor
  public Contacts { 
    total = 0; //set total to 0
  }
  
  public Contacts(double startingAmount) {
    
  }
  
  // methods
 
  
  // accessor methods getTotal to return the total in the bank
 
}