/* Name: Jacqueline Chung
 * Teacher: Mrs. Andrighetti
 * Date: January 7-18, 2016
 * Description:  
 * 
 * Purpose
 * The Address Book will be used to store a client�s contacts in an organized GUI-based software that will allow one to add, edit, 
 * delete, search, sort and move through contacts easily. It should also save the data stored in the program, so the user can 
 * continue to add the contacts without the hassle of adding them again after the software is closed.
 * 
 * Scope:
 * To design a GUI-based software that stores minimum 100 contacts (with File I/O - read and write program) using Java for an 
 * individual or business. The address book should store a name (first & last), address, email, and phone number. My application 
 * will have buttons for add, delete, edit, search, sort, previous, and next. It will sort the records based on various fields 
 * and search for records based on particular categories assigned by the user using efficient methods. The GUI have components 
 * based on past projects and should use panels for layouts. Object Oriented Programming Concepts and data structures is necessary to store data.
 * 
 * Notes: Ms. A, I wasn't able to get the functionalities to work because  I didn't have enough time, and I
 * was not able to figure out objects. I tried to show what I WOULD have done if it was working.
 * I really hope I don't lose a lot of marks.
 * 
 * I also created a new algorithm, so I attached it with my code. I hope that's okay.
 */

//declare imports 
import java.util.ArrayList;
import java.util.Scanner;
// These imports are required to use GUI components
import javax.swing.*;
import java.awt.*; 
import java.awt.event.*;
//imports for File I/O
import java.io.PrintWriter;
import java.io.File;
//import java.io.*;

public class AddressBookGUI extends JFrame implements ActionListener{ //Jframe and Actionlistener needed for buttons and frame
  //class variables
  
  //declare array list
  ArrayList<Object> contacts = new ArrayList<Object>(); // Create an ArrayList that holds references to String

  //Create some GUI components
  //JPanel tab panels
  JPanel tabpan1 = new JPanel(); //Contact List, edit, delete and save contacts
  JPanel tabpan2 = new JPanel(); //Search function
  JPanel tabpan3 = new JPanel(); //about/help info, instructions to software
  
  // Create tabbed panes 
  JTabbedPane Tabbed = new JTabbedPane(JTabbedPane.TOP); //declare tabbed pane
  
  //create panels 
  JPanel pan1 = new JPanel(); //for title and scrollbar
  JPanel namePan = new JPanel(); //for name
  JPanel addressPan = new JPanel(); //for address
  JPanel infoPan = new JPanel(); // for rest of information
  JPanel buttonPan = new JPanel(); //buttons for tabpan1
  //for tabpan2
  JPanel pan2 = new JPanel(); 
  JPanel pan3 = new JPanel(); 
  JPanel pan4 = new JPanel(); 
  //for tabpan3
  JPanel pan5 = new JPanel();  
  
  //add textfields
  JTextField firstField = new JTextField(27);
  JTextField lastField = new JTextField(27);
  JTextField phoneField = new JTextField(25);
  JTextField emailField = new JTextField(25);
  JTextField companyField = new JTextField(60);
  //address textfields
  JTextField unitField = new JTextField(5);
  JTextField streetField = new JTextField(18);
  JTextField cityField = new JTextField(10);
  JTextField postalField = new JTextField(10);
  JTextField stateField = new JTextField(10);
  JTextField countryField = new JTextField(10);
  JTextField searchField = new JTextField(20); //for tabpan2

  //add text area with scrollbar
  JTextArea notesArea = new JTextArea(5, 5);
  JScrollPane scrollPane = new JScrollPane(notesArea); 
  JScrollPane listScrollPane = new JScrollPane(); 
  JScrollPane searchScrollPane = new JScrollPane(); 
  
  //add labels for tabpan1
  JLabel titleLabel = new JLabel("ADDRESS BOOK - Jacqueline Chung"); //title
  //labels for fields
  JLabel firstLabel = new JLabel("First Name: ", JLabel.RIGHT);   
  JLabel lastLabel = new JLabel("Last Name: ", JLabel.RIGHT);
  JLabel addressLabel = new JLabel("Address: ", JLabel.RIGHT);
  JLabel phoneLabel = new JLabel("Phone: ", JLabel.RIGHT);
  JLabel emailLabel = new JLabel("Email Address: ", JLabel.RIGHT);
  JLabel companyLabel = new JLabel("Company: ", JLabel.RIGHT);
  JLabel notesLabel = new JLabel("Notes: ", JLabel.RIGHT);
  JLabel countLabel = new JLabel("Contacts: " + contacts.size(), JLabel.RIGHT); //doesn't count properly!!

  //add labels to tabpan2
  JLabel search1Label = new JLabel("Search by: ", JLabel.RIGHT);
  JLabel search2Label = new JLabel("Enter contact to search for: ", JLabel.RIGHT);
  JLabel resultsLabel = new JLabel("Results: " + "Contacts", JLabel.RIGHT);
  
  //Help/Info Labels for Help/Info tab 
  JLabel help1Label = new JLabel("ADDRESS BOOK APPLICATION", JLabel.CENTER);
  JLabel help2Label = new JLabel(" ", JLabel.CENTER);
  JLabel help3Label = new JLabel("Creator: Jacqueline Chung", JLabel.CENTER);
  JLabel help4Label = new JLabel("Date: January 18, 2016", JLabel.CENTER);
  JLabel help5Label = new JLabel(" ", JLabel.CENTER);
  JLabel help6Label = new JLabel("The Address Book Application (ABA) can be used to add, delete, sort, and edit contacts, which will be stored in a text file (File I/O).", JLabel.CENTER); ////ad more info
  JLabel help7Label = new JLabel(" ", JLabel.CENTER);
  JLabel help8Label = new JLabel("Tab #1: Contacts", JLabel.CENTER);
  JLabel help9Label = new JLabel("- Scrollbar pane displays all contacts in address book", JLabel.CENTER);
  JLabel help10Label = new JLabel("- Enter contact's information with AT LEAST the name and one other piece of information", JLabel.CENTER);
  JLabel help12Label = new JLabel("- Press buttons on the bottom of screen to Edit, Delete, Save or Clear the information", JLabel.CENTER);
  JLabel help13Label = new JLabel("Please note: it is important you write information in proper format.", JLabel.CENTER);
  JLabel help14Label = new JLabel("For example, Email Address: ABC@DEF.com/ca/org/net; Phone Number: Only contain numbers; ", JLabel.CENTER);
  JLabel help15Label = new JLabel(" ", JLabel.CENTER);
  JLabel help16Label = new JLabel("Tab #2: Search", JLabel.CENTER);
  JLabel help17Label = new JLabel("- Pick Category (drop down menu) to search contact accordingly", JLabel.CENTER);
  JLabel help18Label = new JLabel("- Enter contact's first or last name in text field and click the Search button", JLabel.CENTER);
  JLabel help19Label = new JLabel("- Scroll pane is used to display the results of the search", JLabel.CENTER);
  JLabel help20Label = new JLabel("- Double click to open contact in Contact Tab", JLabel.CENTER); ///////////make sure to do this!!
  
  //create  buttons for tab1
  JButton editButton = new JButton("Save Changes");
  JButton deleteButton = new JButton("Delete"); 
  JButton addButton = new JButton("Add Contact"); 
  JButton clear1Button = new JButton("Clear"); 
  
  //create buttons for tab2
  JButton searchButton = new JButton("Search"); 
  JButton clear2Button = new JButton("Clear Search"); 
  
  //add fonts
  Font font1 = new Font("Serif", Font.BOLD, 25); //font for title
  Font font2 = new Font("Serif Sans", Font.BOLD, 18); //font for help texts
  Font font3 = new Font("Serif Sans", Font.ITALIC, 12); //font for help texts
  
  //create comboboxes
  static final JComboBox categoryList = new JComboBox();
  
  //create dialog box to give messages
  static int mc = JOptionPane.WARNING_MESSAGE; //warning dialog box
  int em = JOptionPane.ERROR_MESSAGE; //error dialog box
  
  static Scanner myScanner = new Scanner(System.in);//declare scanner class as a global variable
  
  //scrollbar, declare lists
  public static DefaultListModel listModel = new DefaultListModel(); 
  JList list = new JList(listModel);
  
  public static DefaultListModel searchListModel = new DefaultListModel(); 
  JList searchList = new JList(searchListModel);

  //file I/O
  File myFile ;
  PrintWriter output ; //java.io.PrintWriter class can be used to create a file and write data to a text file

  Scanner input;//declare scanner for file reader
  
  AddressBook contactsList; // create an new AddressBook object.
  
  ////////////////////////CONSTRUCTOR//////////////////
  public AddressBookGUI() {  //a special method called a constructor. It must have the same name as your class. This is where all your code goes to set up the frame 
    setTitle("ADDRESS BOOK - Jacqueline Chung"); //Create a window with a title
    setSize(830, 600); // set the window size    
    setResizable(false); // prevents user from changing the size 
    
    //lists with scrollbars
    listScrollPane.getViewport().add(list);   //add scroll pane to the JList list
    searchScrollPane.getViewport().add(searchList);   //add scroll pane to the JList list
    
    // set layout  for everything
    setLayout(new GridLayout());
    
    //create Box Layouts (can't be shared)
    BoxLayout layout1 = new BoxLayout(pan1, BoxLayout.Y_AXIS);
    BoxLayout layout2 = new BoxLayout(pan2, BoxLayout.Y_AXIS);
    BoxLayout layout3 = new BoxLayout(buttonPan, BoxLayout.X_AXIS);
    BoxLayout layout4 = new BoxLayout(pan4, BoxLayout.X_AXIS);    
    BoxLayout layout5 = new BoxLayout(pan5, BoxLayout.Y_AXIS);
    
    //set layouts for panels
    pan1.setLayout(layout1);
    buttonPan.setLayout(layout3);
    namePan.setLayout(new FlowLayout());
    pan2.setLayout(layout2);
    pan4.setLayout(layout4);
    pan5.setLayout(layout5);
    
    //get content for tabs
    getContentPane().add(Tabbed);   
    
    //set colour background for the tabs
    tabpan1.setBackground(Color.orange);
    tabpan2.setBackground(Color.pink);
    tabpan3.setBackground(Color.green);
    
    //set colour background for panels
    pan1.setBackground(Color.orange);
    pan2.setBackground(Color.orange);
    namePan.setBackground(Color.orange);
    addressPan.setBackground(Color.orange);
    infoPan.setBackground(Color.orange);
    pan3.setBackground(Color.white);
    pan4.setBackground(Color.pink);
    pan5.setBackground(Color.green);
    
    //set font
    titleLabel.setFont(font1);
    help1Label.setFont(font2);
    help13Label.setFont(font3);
    help14Label.setFont(font3);
    
    /////////set text for address information//////////
    unitField.setText ("Unit #"); 
    streetField.setText ("Street Address"); 
    cityField.setText ("City Name"); 
    postalField.setText ("Postal/ZIP Code"); 
    stateField.setText("Province/State Name"); 
    countryField.setText ("Country Name"); 
    
    //////////////////ADD COMPONENTS\\\\\\\\\\\\\\\\\\\\
    //add tabs
    add(tabpan1);
    add(tabpan2);
    add(tabpan3);
    
    //add some panels to tabpan1
    tabpan1.add(pan1);
    tabpan1.add(namePan);
    //add some panels to tabpan2
    tabpan2.add(pan3);
    tabpan2.add(pan4);
    //add panel to tabpan3
    tabpan3.add(pan5);
    
    //set Tab titles
    Tabbed.addTab("Contacts", tabpan1);
    Tabbed.addTab("Search", tabpan2);
    Tabbed.addTab("Help/Info", tabpan3);
    
////////////////////////////DROP DOWN MENU\\\\\\\\\\\\\\\\\\\\\\\\\
  
    ////////////catrgory dropdown menu
    categoryList.addItem("Pick Category");
    categoryList.addItem("Last Name");
    categoryList.addItem("First Name");
    
    //Create the combo box, select item at index 0    
    categoryList.setSelectedIndex(0);
    categoryList.addActionListener(this);
    categoryList.setEditable(false);
    
/////////////////////////ActionListener (JComboBox)\\\\\\\\\\\\\\\\\\\\\
    //this allows user to click on the different options for the dropdown menu
    categoryList.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent event) {
        
        Object selected = categoryList.getSelectedItem();
        if(selected.toString().equals("Last Name")) {
          System.out.println("Picked Last Name Category");
        } else if(selected.toString().equals("First Name")) {
          System.out.println("Picked First Name Category");
        }
      }
    });

    getContentPane().add(categoryList);
    
    //add title to first tab
    pan1.add(titleLabel);
        
    //add scrollbar to list
    pan1.add(listScrollPane, BorderLayout.CENTER);
    listScrollPane.setVerticalScrollBarPolicy (JScrollPane.VERTICAL_SCROLLBAR_ALWAYS); //display scrollbar at all times
    list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); //ensure user can only choose one item at a time
    
    //when list item is double clicked, set text fields to saved information
    //it was supposed to edit information if it worked! (opening the clicked contact information and pop up to allow for editing)
    list.addMouseListener(new MouseAdapter() { //create listener for mouse clicks
      public void mouseClicked(MouseEvent evt) {
        if (evt.getClickCount() == 2) {
          //readFile();
        }
      }
    });
    
    //add counter for number of contacts
    pan1.add(countLabel);
    
    //add text fields with labels
    ///////name panel and label////////////
    namePan.add(firstLabel);
    namePan.add(firstField);
    
    namePan.add(lastLabel);
    namePan.add(lastField);
    
    ////adress panels and labels//////
    tabpan1.add(addressPan);
    addressPan.add(addressLabel);
    addressPan.add(unitField);
    addressPan.add(streetField);
    addressPan.add(cityField);
    addressPan.add(postalField);
    addressPan.add(stateField);
    addressPan.add(countryField);
    
    //add to rest of information with panels and labels
    tabpan1.add(infoPan);
    infoPan.add(phoneLabel);
    infoPan.add(phoneField);
    
    infoPan.add(emailLabel);
    infoPan.add(emailField);
    
    //add pan2
    tabpan1.add(pan2);
    pan2.add(companyLabel);
    pan2.add(companyField);
    
    pan2.add(notesLabel);
    pan2.add(notesArea);
    
    // Adds actionListener to the Buttons 
    editButton.addActionListener(this);
    deleteButton.addActionListener(this);
    addButton.addActionListener(this);
    clear1Button.addActionListener(this);

    //add buttons
    tabpan1.add(buttonPan); 
    buttonPan.add(editButton);
    buttonPan.add(deleteButton);
    buttonPan.add(addButton);
    buttonPan.add(clear1Button);
    
    //////add components to tabpan2///////
    //add actionListener
    searchButton.addActionListener(this);
    clear2Button.addActionListener(this);
    
    //add panels
    tabpan2.add(pan3);
    tabpan2.add(pan4);
    //add labels, drop down menu, buttons and text field
    pan3.add(search1Label);
    pan3.add(categoryList);
    pan3.add(search2Label);
    pan3.add(searchField); 
    pan3.add(searchButton); 
    pan3.add(clear2Button); 
    
    //add labels in tabpan3
    tabpan3.add(pan5);
    pan5.add(help1Label);
    pan5.add(help2Label);
    pan5.add(help3Label);
    pan5.add(help4Label);
    pan5.add(help5Label);
    pan5.add(help6Label);
    pan5.add(help7Label);
    pan5.add(help8Label);
    pan5.add(help9Label);
    pan5.add(help10Label);
    pan5.add(help12Label);
    pan5.add(help13Label);
    pan5.add(help14Label);
    pan5.add(help15Label);
    pan5.add(help15Label);
    pan5.add(help16Label);
    pan5.add(help17Label);
    pan5.add(help18Label);
    pan5.add(help19Label);
    pan5.add(help20Label);
    
    //add scrollbar for search results
    //if it worked it would print the information that was searched, maybe a list or just individual result
    pan4.add(searchScrollPane, BorderLayout.CENTER);
    searchScrollPane.setVerticalScrollBarPolicy (JScrollPane.VERTICAL_SCROLLBAR_ALWAYS); //display scrollbar at all times
    searchList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); //ensure user can only choose one item at a time
    
    setVisible(true); // makes it visible 
  }
  
  //////////////////***ACTION (EVENT) LISTENER***\\\\\\\\\\\\\\\\\\\\
  //This method runs when an event occurs, Code in here only runs when a user interacts with a component
  public void actionPerformed(ActionEvent event) {
    String command = event.getActionCommand(); //finds name of GUI component
    
    //////////////////SAVE CHANGES TO CONTACT////////////////
    if (command.equals("Save Changes")) { //if a button was pressed
      System.out.println("Save Changes button pressed"); //test on console
      
      //declare new variables for setter methods
      String newFirst = firstField.getText();
      String newLast = lastField.getText();
      String newUnit = unitField.getText();
      String newStreet = streetField.getText();
      String newCity = cityField.getText();
      String newPostal = postalField.getText();
      String newState = stateField.getText();
      String newCountry = countryField.getText();
      String newPhone = phoneField.getText();
      String newEmail = emailField.getText();
      String newCompany = companyField.getText();
      String newNotes = notesArea.getText();
      //this sends in information
      contactsList = new AddressBook(newFirst, newLast, newUnit, newStreet, newCity, newPostal, newState, newCountry, newPhone, newEmail, newCompany, newNotes); 
      //print information for contact
      System.out.println("Name: " + firstField.getText() + ", " + lastField.getText()); 
      System.out.println("Address: " + unitField.getText() + " " + streetField.getText() + ", " + cityField.getText() + postalField.getText() + ", " + stateField.getText() + ", " + countryField.getText());
      System.out.println("Phone: " + phoneField.getText());
      System.out.println("Email Address: " + emailField.getText());
      System.out.println("Company: " + companyField.getText());
      System.out.println("Notes: " + notesArea.getText() + "\n");
      
      JOptionPane.showMessageDialog (null, "Changes saved!", "Information", JOptionPane.INFORMATION_MESSAGE);   //dialog box to tell user changes were saved  
      
      ///////////////////DELETE CONTACT///////////////////////
    } else if (command.equals("Delete")) { //if a button was pressed
      System.out.println("Delete button pressed"); //test on console
      
      if (contacts.isEmpty()) { //if the coins arraylist is empty
        System.out.println("Address Book is empty!"); //print message that the bank is empty
        
      }
      
      int deleteIndex = list.getSelectedIndex(); //declare index that was selected in list
      
      listModel.removeElement(list.getSelectedValue()); //remove element
      contacts.remove(deleteIndex); //remove contact from selected index
      
      System.out.println(contacts.get(deleteIndex)); //print index that is removed
      
      JOptionPane.showMessageDialog (null, "Contact deleted!", "Information", JOptionPane.INFORMATION_MESSAGE);   //dialog box to tell user the contact was deleted  
      
      ////////////////////////ADD CONTACT/////////////////////
    } else if (command.equals("Add Contact")) { //if a button was pressed
      System.out.println("Add Contact button pressed"); //test on console
      
      //declare variables for fields
      String first = firstField.getText(); 
      String last = lastField.getText(); 
      String unit = unitField.getText(); 
      String street = streetField.getText(); 
      String city = cityField.getText(); 
      String postal = postalField.getText(); 
      String state = stateField.getText(); 
      String country = countryField.getText(); 
      String email = emailField.getText(); 
      String phone = phoneField.getText(); 
      String company = companyField.getText(); 
      String notes = notesArea.getText(); 

      /////////////validation///////////////
      if (first.equals("")) {   //if the first name field is empty       
        JOptionPane.showMessageDialog (null, "Please enter the first name.", "Message", mc); //warn the user that they need to enter a first name      
        System.out.println ("Please enter the first name."); //test console
      } 
      
      if (last.equals("")) {   //if the last name field is empty       
        JOptionPane.showMessageDialog (null, "Please enter the last name.", "Message", mc); //warn the user that they need to enter a last name       
        System.out.println ("Please enter the last name.");//test console
      } 
      
      if ((unit.equals("") && street.equals("")  && city.equals("")  && postal.equals("")  && state.equals("")  && country.equals(""))  && phone.equals("")  && email.equals("")  && company.equals("")  && notes.equals("") ) {   //if the phone field is empty       
        JOptionPane.showMessageDialog (null, "Please enter at least one piece of information.", "Message", mc); //warn the user that they need to enter a phone number       
        System.out.println ("Please enter at least one piece of information.");//test console
      } 
      
      if (!unit.equals ("") && !unit.matches("[0-9]+")) {//if address unit is not numbers
        JOptionPane.showMessageDialog (null, "Remember, the unit number must contain valid characters! Please enter it again.", "Message", mc); //warn the user that they need to enter a valid characters in the address       
        System.out.println ("Remember, the unit number must contain valid characters! Please enter it again.");//test console
      }
      
      if (!unit.equals ("") || !street.equals("")  || !city.equals("")  || !postal.equals("")  || !state.equals("")  || !country.equals("")) {//if address unit is not numbers
        JOptionPane.showMessageDialog (null, "Please enter all the necessary address fields!", "Message", mc); //warn the user that they need to enter a valid characters in the address       
        System.out.println ("Please enter all the necessary address fields!");//test console
      }
      
      if (!phone.matches("[0-9]+") && !phone.equals("")) {//if phone number invalid
        JOptionPane.showMessageDialog (null, "Remember, the phone number must contain valid characters! Please enter it again.", "Message", mc);//give warning to user that the input is invalid         
        System.out.println("Remember, the phone number must contain valid characters! Please enter it again."); //output message that the input is invalid
        //set value as a space
        phone = " ";
        phoneField.setText ("");     
      }
      
      if (!email.matches ("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$") && !email.equals("")) {//if   email not valid    
        JOptionPane.showMessageDialog (null, "Remember, the email address must contain valid characters! Please enter it again.", "Message", em);   //warn user that they didn't enter vlaid characters                  
        System.out.println("Remember, the email address must contain valid characters! Please enter it again."); //output message that there are no users inputted
        //set value as space
        email = " ";
        emailField.setText ("");
      }
      
      //if the following is valid
      if (!last.equals ("") && !first.equals ("") && ((email.matches ("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$") && !email.equals("")) || (phone.matches("[0-9]+")  && !phone.equals("")) || (!unit.equals("")  && !street.equals("")  && !city.equals("")  && !postal.equals("")  && !state.equals("")  && !country.equals(""))  || !company.equals("")  || !notes.equals("") )) { //if fields are valid
        contactsList = new AddressBook(first,  last,  unit,  street,  city,  postal,  state,  country,  email,  phone,  company,  notes);
        listModel.addElement (contactsList.getLastName() + ", " + contactsList.getFirstName()); //add last name and the first name onto the list

        contacts.add(contactsList); //add object to arraylist
        
        //print information for contact
        System.out.println("Name: " + contactsList.getLastName() + ", " + contactsList.getFirstName()); 
        System.out.println("Address: " + unitField.getText() + " " + streetField.getText()  + ", " + cityField.getText() + postalField.getText() + ", " + stateField.getText() + ", " + countryField.getText());
        System.out.println("Phone: " + phoneField.getText());
        System.out.println("Email Address: " + emailField.getText());
        System.out.println("Company: " + companyField.getText());
        System.out.println("Notes: " + notesArea.getText() + "\n");

        //try and catch
        try {
          writeFile(); //CALL WRITE FILE METHOD
        } catch (Exception e) {}
        
        JOptionPane.showMessageDialog (null, "Contact added!", "Information", JOptionPane.INFORMATION_MESSAGE);   //dialog box to tell user the contact was added 
        
        //fields cleared after save
        firstField.setText ("");
        lastField.setText ("");
        unitField.setText ("");
        streetField.setText ("");
        cityField.setText ("");
        postalField.setText ("");
        stateField.setText ("");
        countryField.setText ("");
        phoneField.setText ("");
        emailField.setText ("");
        companyField.setText ("");
        notesArea.setText ("");
        
        //THIS WAS SUPPOSED TO SORT ARRAY BUT IT DOESN'T WORK AND IT HAS RED STUFF SHOWING UP
      //  InsertionSort();//sort array list 
        
      }
      /////////////////CLEAR BUTTON/////////////
    } else if (command.equals("Clear")) { //if a button was pressed
      System.out.println("Clear button pressed"); //test on console
      //clear text fields (blank)
      firstField.setText ("");
      lastField.setText ("");
      unitField.setText ("");
      streetField.setText ("");
      cityField.setText ("");
      postalField.setText ("");
      stateField.setText ("");
      countryField.setText ("");
      phoneField.setText ("");
      emailField.setText ("");
      companyField.setText ("");
      notesArea.setText ("");
      
      JOptionPane.showMessageDialog (null, "Fields cleared!", "Information", JOptionPane.INFORMATION_MESSAGE);   //dialog box to tell user the text fields were cleared
      
    } else if (command.equals("Clear Search")) { //if a button was pressed
      System.out.println("Clear Search button pressed"); //test on console
      searchField.setText (""); //clear search field
      
    } else if (command.equals("Search")) { //if a button was pressed
      System.out.println("Search button pressed"); //test on console 
      
      String name = searchField.getText(); //declare search
      
      binarySearch(name);
      System.out.println("Name Searched:" + name);
      
      //the drop down menu is supposed to give user option to search by first or last name
    }
  }
  
  //********************OUTPUT********************
  public void writeFile () throws Exception {
    myFile = new File("newEntry.txt");
    output = new PrintWriter(myFile); //java.io.PrintWriter class can be used to create a file and write data to a text file 
    //print information into text file
    //for some reason, it keeps replacing the info in the text file
    output.println(contactsList.getFirstName());
    output.println(contactsList.getLastName());
    output.println(contactsList.getUnit());
    output.println(contactsList.getStreet());
    output.println(contactsList.getCity());
    output.println(contactsList.getPostal());
    output.println(contactsList.getState());
    output.println(contactsList.getCountry());
    output.println(contactsList.getPhone());
    output.println(contactsList.getEmail());
    output.println(contactsList.getCompany());
    output.println(contactsList.getNotes());
    
    output.close(); //close file
  }
  
  ///////////////reading (input)///////////////////
  public void readFile() throws Exception {
    input = new Scanner(myFile); //declare input from file
      
    while (input.hasNext()) { // Read data from a file
      String firstName = input.next();
      String lastName = input.next();
      int unit = input.nextInt();
      String street = input.next();
      String city = input.next();
      String postal = input.next();
      String state = input.next();
      String country = input.next();
      String phone = input.next();
      String email = input.next();
      String company = input.next();
      String notes = input.next();
    }
    input.close(); // Close the file
  }
  
/////sort the list of contacts alphabetically /////
/////////////////insertion sort///////////////////////
  public void InsertionSort () {
    //convert into array
    String[] cEntries = new String[contacts.size()];
    contacts.toArray(cEntries);
    
    //declare temp values to swap elements
    int j;
    String temp; 
    
    listModel.removeAllElements(); //remove all the elements from the list to output them alphabetically 
    
    System.out.println("The list of contact names: "); //print contact lists
    for (int i = 0; i < cEntries.length; i++) {
      System.out.println(cEntries[i]); //output names   
    }
    
    //swap elements
    for (int i = 1; i < cEntries.length; i++)  {
      temp = cEntries[i] ; 
      j =  i ;      
      
      //comparison doens't work for it deals with objects and string arrays (not compatible??)
//      while (j > 0 && cEntries[j � 1].compareTo(temp) > 0) {
//        cEntries[j] = cEntries[ j � 1 ]; //swap
//        j -- ;   
//      } // while loop ends
      cEntries[j] = temp; //swap
    } // for loop ends
    
    for (int i = 0; i < cEntries.length; i++) {
      listModel.addElement(cEntries[i]); //add the element sorted
      System.out.println(cEntries[i]);//output to test console
    }
  } // method ends

  public int binarySearch (String fName) { 
    //declare entries and convert into string array
    String[] cEntries = new String[contacts.size()];
    contacts.toArray(cEntries);
    
    //declare variables for cutting list in half
    int low = 0, high = cEntries.length - 1;
    
    //test on console
    System.out.println("The list of contact names: ");
    for (int i = 0; i < contacts.size(); i++) {
      System.out.println(cEntries[i]); //output names   
    }
    
    while (low <= high) { //while the lowest element is lower than the highest element
      System.out.println("Low and High (to be calculated): " + low + " and " + high);
      
      int mid = (high + low) / 2;
      System.out.println("Mid " + mid);
      
      if (cEntries[mid].compareTo(fName) == 0) { //if it matches
        System.out.println("Found in " + mid); //print that it was found
        return mid; //return index it was found
      } else if (cEntries[mid].compareTo(fName) > 0) { //if element is greater
        high = mid - 1;//move higher in the list
        System.out.println("New high " + high); //test in console
      } else { //else
        low = mid + 1; //move higher in the list
        System.out.println("New low " + low); //test in console
      }
    }
    return -1; //not found
  }
  
  
  /////////////////////MAIN METHOD//////////////////////////
//main method -- menu driven application for storing money in a piggy bank
  public static void main(String args[]) throws Exception {  //main method
    AddressBookGUI frame = new AddressBookGUI(); //one line of code to create the frame  
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //when closed it resets interactions
    myScanner.close(); //close Scanner
  } //end main method
} //end class
