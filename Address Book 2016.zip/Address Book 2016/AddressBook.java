/* Name: Jacqueline Chung
 * Teacher: Mrs. Andrighetti
 * Date: January 6, 2015
 * Description:  AddressBook class.  This class stores contact information to the object.
 * AddressBook should now contain a list of information (first name, last name, email, address, phone, company, group, and notes) to represent what is actually stored in the address book.
 * 
 */

//declare imports 
import java.util.ArrayList;

public class AddressBook {
  //declare array
  String[] listOfContacts = new String [100];
//  String[] first = new String[100];
//  String[] last = new String[100];
//  int[] unit = new int[100];
//  String[] street = new String[100];
//  String[] city = new String[100];
//  String[] postal = new String[100];
//  String[] state = new String[100];
//  String[] country = new String[100];
//  String[] phone = new String[100];
//  String[] email = new String[100];
//  String[] company = new String[100];
//  String[] group = new String[100];
//  String[] notes = new String[100];
  int numOfC = 0;
  
  
  
  ArrayList<Object> contacts = new ArrayList<Object>(); // Create an ArrayList that holds references to String
  
  //declare private variables
  private String first;
  private String last;
  private String unit;
  private String street;
  private String city;
  private String postal;
  private String state;
  private String country;
  private String email;
  private String phone;
  private String company;
  private String group;
  private String notes;
  
  public AddressBook (String first, String last, String unit, String street, String city, String postal, String state, String country, String email, String phone, String company, String notes){
    this.first = first;
    this.last = last;
    this.unit = unit;
    this.street = street;
    this.city = city;
    this.postal = postal;
    this.state = state;
    this.country = country;
    this.email = email;
    this.phone = phone;
    this.company = company;
    //this.group = group;
    this.notes = notes;
  }
  
  //initialize fields
  public AddressBook(){
    first = "";
    last = "";
    unit = "";
    street = "";
    city = "";
    postal = "";
    state = "";
    country = "";
    email = "";
    phone = "";
    company = "";
    notes = "";
  }
  
//  // methods
//  ////////////get name input//////////////////
//  public void getFirstName(String firstName) { //add contact
//    numOfC++;
//    listOfContacts[numOfC] = firstName;
//    first[numOfC] = firstName;
//  }
//  
//  public void getLastName(String lastName) { //add contact
//    //listOfContacts[numOfC] = lastName; //return name
//    last[numOfC] = lastName;
//  }
//  
//  ////////////////get address input////////////////
//  public void getUnit(int unit) { //add contact
////    return unit; //return name
//  }
//  
//  public void getStreet(String street) { //add contact
////    return street; //return name
//  }
//  
//  public void getCity(String city) { //add contact
////    return city; //return name
//  }
//  
//  public void getState(String state) { //add contact
////    return state; //return name
//  }
//  
//  public void getCountry(String country) { //add contact
////    return country; //return name
//  }
//  
//  ////////////get phone number/////////////////
//  public void getPhone(String phone) { //add contact
////    return phone; //return name
//  }
//  
//  /////////////get company////////////////////////
//  public void getCompany(String company) { //add contact
////    return company; //return name
//  }
//  
//  public void getGroup(String group) { //add contact
////    return group; //return name
//  }
//  
//  ////////////////get notes///////////////////
//  public void getNote(String note) { //add contact
////    return note; //return name
//  }
  
  //Keeps track of how many entries are in the book
  private int entries = 0;
  AddressBook [] contents = new AddressBook [100];
  
  public int getEntries(){
    return contents.length;
  }
  
//Adds an entry to the book
  public void add(String first, String last, String unit, String street, String city, String postal, String state, String country, String email, String phone, String company, String notes){
    if (entries < contents.length){
      contents[entries] = new AddressBook (first, last, unit, street, city, postal, state, country, email, phone, company, notes);
      entries++;
    }
    else System.out.println("Error: book is full");
  }
  
  //Removes an entry from the book
  public void remove(int entry){
    if (entries>0){
      contents[entry] = new AddressBook();
      for (int i = 0; i < entries-entry; i++){
        if (entry+1==entries) contents[entry] = new AddressBook();
        else{
          AddressBook temp = contents[entry+i];
          contents[entry+i] = contents[entry+i+1]; //Removes an entry end moves each entry after it one backwards.
          contents[entry+i+1] = temp;
        }
      }
      entries--;
    }
    else System.out.println("Error: book is empty.");
  }
  
//Changes the values of an entry
  public void edit(String first, String last, String unit, String street, String city, String postal, String state, String country, String email, String phone, String company, String notes, int selection){
    contents[selection].first = first;
    contents[selection].last = last;
    contents[selection].unit = unit;
    contents[selection].street = street;
    contents[selection].city = city;
    contents[selection].postal = postal;
    contents[selection].state = state;
    contents[selection].country = country;
  }
  
  public String getFirstName() { //add contact
    return first; //return name
  }
  
  public String getLastName() { //add contact
    return last; //return name
  }
  
  ////////////////get address input////////////////
  public String getUnit() { //add contact
    return unit; //return name
  }
  
  public String getStreet() { //add contact
    return street; //return name
  }
  
  public String getCity() { //add contact
    return city; //return name
  }
  
  public String getPostal() { //add contact
    return postal; //return name
  }
  
  public String getState() { //add contact
    return state; //return name
  }
  
  public String getCountry() { //add contact
    return country; //return country
  }
  
  ////////////get phone number/////////////////
  public String getPhone() { //add contact
    return phone; //return phone
  }
  
  ////////////get email/////////////////
  public String getEmail() { //add contact
    return email; //return email
  }
  
  /////////////get company////////////////////////
  public String getCompany() { //add contact
    return company; //return name
  }
  
  public String getGroup() { //add contact
    return group; //return name
  }
  
  ////////////////get notes///////////////////
  public String getNotes() { //add contact
    return notes; //return name
  }
  
  //modifier methods, setter methods
  //this is used to change/edit contact information
  //it might have been used for the sorting functionality 
  public void setFirstName(String f) {
    first = f; 
  }
  
  public void setLastName(String l) {
    last = l; 
  }
  
  public void setUnit(String u) {
    unit = u; 
  }
  
  public void setStreet(String s) {
    street = s; 
  }
  
  public void setCity(String c) {
    city = c; 
  }
  
  public void setPostal(String p) {
    postal = p; 
  }
  
  public void setState(String s) {
    state = s; 
  }
  
  public void setCountry(String c) {
    country = c; 
  }
  
  public void setPhone(String p) {
    phone = p; 
  }
  
  public void setEmail(String e) {
    email = e; 
  }
  
  public void setCompany(String c) {
    company = c; 
  }
  
  public void setGroup(String g) {
    group = g; 
  }
  
  public void setNotes(String n) {
    notes = n; 
  }
  
//  public void removeContact(String name) { //remove coins when user chooses 6
//  }
}