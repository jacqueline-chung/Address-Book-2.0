//this method  

public class Info extends AddressBook {
  
  //declare variables
  String phone;
  String email;
  String company;
  String group;
  String notes;
  
  public Info() { //initialize info
    phone = "";
    email = "";
    company = "";
    group = "";
    notes = "";
  }
  
  public Info(String infoPhone, String infoEmail, String infoCompany, String infoGroup, String infoNotes) { //take in info
    phone = infoPhone;
    email = infoEmail;
    company = infoCompany;
    group = infoGroup;
    notes = infoNotes;
    
  }
  
  public String getPhone() {
    return phone; 
  }
  
  public String getEmail() {
    return email; 
  }
  
  public String getCompany() {
    return company; 
  }
  
  public String getGroup() {
    return group; 
  }
  
  public String getNotes() {
    return notes; 
  }
  
  //modifier methods, setter methods
  public void setPhone(String p) {
    phone = p; 
  }
  
  public void setEmail(String e) {
    email = e; 
  }
  
  public void setCompany(String c) {
    company = c; 
  }
  
  public void setGroup(String g) {
    group = g; 
  }
  
  public void setNotes(String n) {
    notes = n; 
  }
}