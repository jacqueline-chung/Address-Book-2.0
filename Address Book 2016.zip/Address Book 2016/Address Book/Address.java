//this method  

public class Address extends AddressBook {
  
  //declare variables
  int unit;
  String street;
  String city;
  String postal;
  String state;
  String country;
  
  public Address() { //initialize info
    unit = 0; ///zero?
    street = "";
    city = "";
    postal = "";
    state = "";
    country = "";
  }
  
  public Address(int addressUnit, String addressStreet,  String addressCity, String addressPostal, String addressState, String addressCountry) { //take in info
    unit = addressUnit;
    street = addressStreet;
    city = addressCity;
    postal = addressPostal;
    state = addressState;
    country = addressCountry;
  }
  
  public int getUnit() {
    return unit; 
  }
  
  public String getStreet() {
    return street; 
  }
  
  public String getCity() {
    return city; 
  }
  
  public String getPostal() {
    return postal; 
  }
  
  public String getState() {
    return state; 
  }
  
  public String getCountry() {
    return country; 
  }
  
  
  //modifier methods, setter methods
  public void setUnit(int u) {
    unit = u; 
  }
  
  public void setStreet(String s) {
    street = s; 
  }
  
  public void setCity(String c) {
    city = c; 
  }
  
  public void setPostal(String p) {
    postal = p; 
  }
  
  public void setState(String s) {
    state = s; 
  }
  
  public void setCountry(String c) {
    country = c; 
  }
}