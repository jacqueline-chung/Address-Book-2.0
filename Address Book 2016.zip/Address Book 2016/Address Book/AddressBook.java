/* Name: Jacqueline Chung
 * Teacher: Mrs. Andrighetti
 * Date: January 6, 2015
 * Description:  AddressBook class.  This class stores contact information to the object.
 * AddressBook should now contain a list of information (first name, last name, email, address, phone, company, group, and notes) to represent what is actually stored in the address book.
 * 
*/

public class AddressBook {
  // class constants
  
  //constructor
  public AddressBook() { 
    //total = 0; //set total to 0
  }
  
//  public AddressBook(double startingAmount) {
//
//  }
  
  // methods
  ////////////get name input//////////////////
  public String getFirstName(String firstName) { //add contact
    return firstName; //return name
  }
  
  public String getLastName(String lastName) { //add contact
    return lastName; //return name
  }
  
  ////////////////get address input////////////////
  public int getUnit(int unit) { //add contact
    return unit; //return name
  }
  
  public String getStreet(String street) { //add contact
    return street; //return name
  }
  
  public String getCity(String city) { //add contact
    return city; //return name
  }
  
  public String getState(String state) { //add contact
    return state; //return name
  }
  
  public String getCountry(String country) { //add contact
    return country; //return name
  }
  
  ////////////get phone number/////////////////
  public String getPhone(String phone) { //add contact
    return phone; //return name
  }
  
  /////////////get company////////////////////////
  public String getCompany(String company) { //add contact
    return company; //return name
  }
  
  public String getGroup(String group) { //add contact
    return group; //return name
  }
  
  ////////////////get notes///////////////////
  public String getNote(String note) { //add contact
    return note; //return name
  }
  
//  public void removeContact(String name) { //remove coins when user chooses 6
//  }
}