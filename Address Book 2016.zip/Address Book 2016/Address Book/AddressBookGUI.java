/* Name: Jacqueline Chung
 * Teacher: Mrs. Andrighetti
 * Date: January 7-18, 2016
 * Description:  Create a AddressBook application that 
 */

//declare imports 
import java.util.ArrayList;
import java.util.Scanner;
// These imports are required to use GUI components
import javax.swing.*;
import java.awt.*; 
import java.awt.event.*;
//imports for File I/O
import java.io.PrintWriter;
import java.io.File;
import java.io.*;

public class AddressBookGUI extends JFrame implements ActionListener{ //Jframe and Actionlistener needed for buttons and frame
  //class variables
  
  //declare array list
  ArrayList<Object> contacts = new ArrayList<Object>(); // Create an ArrayList that holds references to String
//  ArrayList<Object> names = new ArrayList<Object>(); // Create an ArrayList that holds references to String
//  ArrayList<Object> addresses = new ArrayList<Object>(); // Create an ArrayList that holds references to String
//  ArrayList<Object> phones = new ArrayList<Object>(); // Create an ArrayList that holds references to String
//  ArrayList<Object> emails = new ArrayList<Object>(); // Create an ArrayList that holds references to String
//  ArrayList<Object> companies = new ArrayList<Object>(); // Create an ArrayList that holds references to String
//  ArrayList<Object> groups = new ArrayList<Object>(); // Create an ArrayList that holds references to String
//  ArrayList<Object> notes = new ArrayList<Object>(); // Create an ArrayList that holds references to String
  
  //Create some GUI components
  //JPanel tab panels
  JPanel tabpan1 = new JPanel(); //Contact List, edit, delete and save contacts
  JPanel tabpan2 = new JPanel(); //Search function
  JPanel tabpan3 = new JPanel(); //about/help info, instructions to software
  
  // Create tabbed panes 
  JTabbedPane Tabbed = new JTabbedPane(JTabbedPane.TOP); //declare tabbed pane
  
  //panels 
  JPanel pan1 = new JPanel(); //
  JPanel namePan = new JPanel(); //for name
  JPanel addressPan = new JPanel(); //for address
  JPanel infoPan = new JPanel(); // for rest of information
  JPanel buttonPan = new JPanel(); //buttons for tabpan1
  JPanel pan2 = new JPanel(); //
  JPanel pan3 = new JPanel(); //
  JPanel pan4 = new JPanel(); //
  JPanel pan5 = new JPanel(); //
  //JPanel pan4 = new JPanel(); //
  
  
  //add textfields
  JTextField firstField = new JTextField(27);
  JTextField lastField = new JTextField(27);
  JTextField phoneField = new JTextField(25);
  JTextField emailField = new JTextField(25);
  JTextField companyField = new JTextField(60);
  //address textfields
  JTextField unitField = new JTextField(5);
  JTextField streetField = new JTextField(18);
  JTextField cityField = new JTextField(10);
  JTextField postalField = new JTextField(10);
  JTextField stateField = new JTextField(10);
  JTextField countryField = new JTextField(10);
  JTextField searchField = new JTextField(20); //for tabpan2

  //add text area
  JTextArea notesArea = new JTextArea(5, 5);
  JScrollPane scrollPane = new JScrollPane(notesArea); 
  JScrollPane listScrollPane = new JScrollPane(); 
  JScrollPane searchScrollPane = new JScrollPane(); 
  
  //add labels for tabpan1
  JLabel titleLabel = new JLabel("ADDRESS BOOK - Jacqueline Chung"); //title
  JLabel firstLabel = new JLabel("First Name: ", JLabel.RIGHT);   
  JLabel lastLabel = new JLabel("Last Name: ", JLabel.RIGHT);
  JLabel addressLabel = new JLabel("Address: ", JLabel.RIGHT);
  JLabel phoneLabel = new JLabel("Phone: ", JLabel.RIGHT);
  JLabel emailLabel = new JLabel("Email Address: ", JLabel.RIGHT);
  JLabel companyLabel = new JLabel("Company: ", JLabel.RIGHT);
  JLabel notesLabel = new JLabel("Notes: ", JLabel.RIGHT);
  JLabel countLabel = new JLabel("Contacts: " + contacts.size(), JLabel.RIGHT);

  //add labels to tabpan2
  JLabel search1Label = new JLabel("Search by: ", JLabel.RIGHT);
  JLabel search2Label = new JLabel("Enter contact to search for: ", JLabel.RIGHT);
  JLabel resultsLabel = new JLabel("Results: " + "Contacts", JLabel.RIGHT);
  
  //Help/Info Labels for Help/Info tab 
  JLabel help1Label = new JLabel("ADDRESS BOOK APPLICATION", JLabel.CENTER);
  JLabel help2Label = new JLabel(" ", JLabel.CENTER);
  JLabel help3Label = new JLabel("Creator: Jacqueline Chung", JLabel.CENTER);
  JLabel help4Label = new JLabel("Date: January 18, 2016", JLabel.CENTER);
  JLabel help5Label = new JLabel(" ", JLabel.CENTER);
  JLabel help6Label = new JLabel("The Address Book Application (ABA) can be used to add, delete, sort, and edit contacts, which will be stored in a text file (File I/O).", JLabel.CENTER); ////ad more info
  JLabel help7Label = new JLabel(" ", JLabel.CENTER);
  JLabel help8Label = new JLabel("Tab #1: Contacts", JLabel.CENTER);
  JLabel help9Label = new JLabel("- Scrollbar pane displays all contacts in address book", JLabel.CENTER);
  JLabel help10Label = new JLabel("- Enter contact's information with AT LEAST the name and one other piece of information", JLabel.CENTER);
  JLabel help11Label = new JLabel("- Add each contact in a proper group (e.g. Family, Friends, Other, etc)", JLabel.CENTER);
  JLabel help12Label = new JLabel("- Press buttons on the bottom of screen to Edit, Drlete, Save or Clear the information", JLabel.CENTER);
  //JLabel help7Label = new JLabel("*Edit button can make text fields editable if necessary", JLabel.CENTER);
  JLabel help13Label = new JLabel("Please note: it is important you write information in proper format.", JLabel.CENTER);
  JLabel help14Label = new JLabel("For example, Email Address: ABC@DEF.com/ca/org/net; Phone Number: Only contain numbers; ", JLabel.CENTER);
  JLabel help15Label = new JLabel(" ", JLabel.CENTER);
  JLabel help16Label = new JLabel("Tab #2: Search", JLabel.CENTER);
  JLabel help17Label = new JLabel("- Pick Category (drop down menu) to search contact accordingly", JLabel.CENTER);
  JLabel help18Label = new JLabel("- Enter contact's name or group in text field and click the Search button", JLabel.CENTER);
  JLabel help19Label = new JLabel("- Scroll pane is used to display the results of the search", JLabel.CENTER);
  JLabel help20Label = new JLabel("- Double click to open contact in Contact Tab", JLabel.CENTER); ///////////make sure to do this!!
  
  // buttons for tab1
  JButton editButton = new JButton("Edit");
  JButton deleteButton = new JButton("Delete"); 
  JButton saveButton = new JButton("Save"); 
  JButton clear1Button = new JButton("Clear"); 
  
  //buttons for tab2
  JButton searchButton = new JButton("Search"); 
  JButton clear2Button = new JButton("Clear Search"); 
  
  //add fonts
  Font font1 = new Font("Serif", Font.BOLD, 25); //font for title
  Font font2 = new Font("Serif Sans", Font.BOLD, 18); //font for title
  Font font3 = new Font("Serif Sans", Font.ITALIC, 12); //font for title
  
  //comboboxes
  static final JComboBox groupList = new JComboBox();
  static final JComboBox categoryList = new JComboBox();
  
  //dialog box to give messages
  static int mc = JOptionPane.WARNING_MESSAGE; //declare option pane as a global variable
  JOptionPane optionPane = new JOptionPane();
  
  static Scanner myScanner = new Scanner(System.in);//declare scanner class as a global variable
  
  //scrollbar, declare list
  public static DefaultListModel listModel = new DefaultListModel(); 
  JList list = new JList(listModel);
//  list.setPreferredSize(new Dimension(250, 440)); //set dimensiosn to scroll pane
  
  public static DefaultListModel searchListModel = new DefaultListModel(); 
  JList searchList = new JList(searchListModel);

  //file I/O
  File myFile ;
  PrintWriter output ; //java.io.PrintWriter class can be used to create a file and write data to a text file

  Scanner input;//declare scanner for file reader
  
  AddressBook contactsList = new AddressBook(); // create an new AddressBook object.
  
  //create new objects with subclasses
  FullName fullName = new FullName();
  Address address = new Address();
  Info info = new Info();
  
  ////////////////////////CONSTRUCTOR//////////////////
  public AddressBookGUI() {  //a special method called a constructor. It must have the same name as your class. This is where all your code goes to set up the frame 
    setTitle("ADDRESS BOOK - Jacqueline Chung"); //Create a window with a title
    setSize(830, 600); // set the window size    
    //setResizable(false); // prevents user from changing the size 
    
    listScrollPane.getViewport().add(list);   //add scroll pane to the JList list
    searchScrollPane.getViewport().add(searchList);   //add scroll pane to the JList list
    
    // set layout 
    setLayout(new GridLayout());
    
    //create ox Layouts (can't be shared)
    BoxLayout layout1 = new BoxLayout(pan1, BoxLayout.Y_AXIS);
    BoxLayout layout2 = new BoxLayout(pan2, BoxLayout.Y_AXIS);
    BoxLayout layout3 = new BoxLayout(buttonPan, BoxLayout.X_AXIS);
    BoxLayout layout4 = new BoxLayout(pan4, BoxLayout.X_AXIS);    
    BoxLayout layout5 = new BoxLayout(pan5, BoxLayout.Y_AXIS);
    
    //set layouts for panels
    pan1.setLayout(layout1);
    buttonPan.setLayout(layout3);
    namePan.setLayout(new FlowLayout());
    pan2.setLayout(layout2);
    
    pan4.setLayout(layout4);
    
    pan5.setLayout(layout5);
    
    //get content
    getContentPane().add(Tabbed);   
    
    //set colour background for the tabs
    tabpan1.setBackground(Color.orange);
    tabpan2.setBackground(Color.pink);
    tabpan3.setBackground(Color.green);
    
    //set colour background for panels
    pan1.setBackground(Color.orange);
    pan2.setBackground(Color.orange);
    namePan.setBackground(Color.orange);
    addressPan.setBackground(Color.orange);
    infoPan.setBackground(Color.orange);
    pan3.setBackground(Color.white);
    pan4.setBackground(Color.pink);
    pan5.setBackground(Color.green);
    
    //set font
    titleLabel.setFont(font1);
    help1Label.setFont(font2);
    help13Label.setFont(font3);
    help14Label.setFont(font3);
    
    /////////set text//////////
    unitField.setText ("Unit #"); //
    streetField.setText ("Street Address"); //
    cityField.setText ("City Name"); //
    postalField.setText ("Postal/ZIP Code"); //
    stateField.setText("Province/State Name"); //
    countryField.setText ("Country Name"); //
    
    //////////////////***ADD COMPONENTS***\\\\\\\\\\\\\\\\\\\\
    //add tabs
    add(tabpan1);
    add(tabpan2);
    add(tabpan3);
    
    //add some panels to tabpan1
    tabpan1.add(pan1);
    tabpan1.add(namePan);
    //add some panels to tabpan2
    tabpan2.add(pan3);
    tabpan2.add(pan4);
//    tabpan2.add(pan5);
//    tabpan2.add(pan6);
//    tabpan3.add(pan7);
    
    //set Tab titles
    Tabbed.addTab("Contacts", tabpan1);
    Tabbed.addTab("Search", tabpan2);
    Tabbed.addTab("Help/Info", tabpan3);
    
////////////////////////////DROP DOWN MENU\\\\\\\\\\\\\\\\\\\\\\\\\
    //group drop down menu
    groupList.addItem("Pick Group");
    
    //Create the combo box, select item at index 0    
    groupList.setSelectedIndex(0);
    groupList.addActionListener(this);
    groupList.setEditable(true);
    
    ////////////catrgory dropdown menu
    categoryList.addItem("Pick Category");
    categoryList.addItem("Last Name");
    categoryList.addItem("First Name");
    categoryList.addItem("Group");
    
    //Create the combo box, select item at index 0    
    categoryList.setSelectedIndex(0);
    categoryList.addActionListener(this);
    categoryList.setEditable(false);
    
/////////////////////////ActionListener (JComboBox)\\\\\\\\\\\\\\\\\\\\\
    categoryList.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent event) {
        
        Object selected = categoryList.getSelectedItem();
//        if(selected.toString().equals("Pick Group")) {
//          System.out.println("Picked Group");
//        } 
      }
    });
    
    categoryList.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent event) {
        
        Object selected = categoryList.getSelectedItem();
        if(selected.toString().equals("Last Name")) {
          System.out.println("Picked Last Name Category");
        } else if(selected.toString().equals("First Name")) {
          System.out.println("Picked First Name Category");
        } else if(selected.toString().equals("Group")) {
          System.out.println("Picked Group Category");
        }
      }
    });
    
    getContentPane().add(groupList);
    getContentPane().add(categoryList);
    
    //add title
    pan1.add(titleLabel);
        
    //add scrollbar
    pan1.add(listScrollPane, BorderLayout.CENTER);
    listScrollPane.setVerticalScrollBarPolicy (JScrollPane.VERTICAL_SCROLLBAR_ALWAYS); //display scrollbar at all times
    list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); //ensure user can only choose one item at a time
    
    //add counter for number of contacts
    pan1.add(countLabel);
    
    //add text fields with labels
    ///////name pan////////////
    namePan.add(firstLabel);
    namePan.add(firstField);
    
    namePan.add(lastLabel);
    namePan.add(lastField);
    
    ////adress pan//////
    tabpan1.add(addressPan);
    addressPan.add(addressLabel);
    addressPan.add(unitField);
    addressPan.add(streetField);
    addressPan.add(cityField);
    addressPan.add(postalField);
    addressPan.add(stateField);
    addressPan.add(countryField);
    
    //add to rest of information
    tabpan1.add(infoPan);
    infoPan.add(phoneLabel);
    infoPan.add(phoneField);
    
    infoPan.add(emailLabel);
    infoPan.add(emailField);
    
//    infoPan.add(companyLabel);
//    infoPan.add(companyField);
    
    //add pan2
    tabpan1.add(pan2);
    pan2.add(companyLabel);
    pan2.add(companyField);
    
    pan2.add(groupList);//add drop down menu
    
    pan2.add(notesLabel);
    pan2.add(notesArea);
    
    // Adds actionListener to the Buttons 
    editButton.addActionListener(this);
    deleteButton.addActionListener(this);
    saveButton.addActionListener(this);
    clear1Button.addActionListener(this);

    //add buttons
    tabpan1.add(buttonPan); 
    buttonPan.add(editButton);
    buttonPan.add(deleteButton);
    buttonPan.add(saveButton);
    buttonPan.add(clear1Button);
    
    //////add components to tabpan2///////
    //add actionListener
    searchButton.addActionListener(this);
    clear2Button.addActionListener(this);
    
    //add panels
    tabpan2.add(pan3);
    tabpan2.add(pan4);
    //add labels, drop down menu, buttons and text field
    pan3.add(search1Label);
    pan3.add(categoryList);
    pan3.add(search2Label);
    pan3.add(searchField); 
    pan3.add(searchButton); 
    pan3.add(clear2Button); 
    
    //add labels in tabpan3
    tabpan3.add(pan5);
    pan5.add(help1Label);
    pan5.add(help2Label);
    pan5.add(help3Label);
    pan5.add(help4Label);
    pan5.add(help5Label);
    pan5.add(help6Label);
    pan5.add(help7Label);
    pan5.add(help8Label);
    pan5.add(help9Label);
    pan5.add(help10Label);
    pan5.add(help11Label);
    pan5.add(help12Label);
    pan5.add(help13Label);
    pan5.add(help14Label);
    pan5.add(help15Label);
    pan5.add(help15Label);
    pan5.add(help16Label);
    pan5.add(help17Label);
    pan5.add(help18Label);
    pan5.add(help19Label);
    pan5.add(help20Label);
    //pan5.add(help16Label);
    
    //add scrollbar for search results
    pan4.add(searchScrollPane, BorderLayout.CENTER);
    searchScrollPane.setVerticalScrollBarPolicy (JScrollPane.VERTICAL_SCROLLBAR_ALWAYS); //display scrollbar at all times
    searchList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); //ensure user can only choose one item at a time
    
    ///////add double mouse click////////
    searchList.addMouseListener(new MouseAdapter() { //create listener for mouse clicks
      public void mouseClicked(MouseEvent evt) {
        if (evt.getClickCount() == 2) {
          System.out.println("Double clicked"); //test on console
        }
      }
    });
    
    
    setVisible(true); // makes it visible 
  }
  
  //////////////////***ACTION (EVENT) LISTENER***\\\\\\\\\\\\\\\\\\\\
  //This method runs when an event occurs, Code in here only runs when a user interacts with a component
  public void actionPerformed(ActionEvent event) {
    String command = event.getActionCommand(); //finds name of GUI component
    
    if (command.equals("Edit")) { //if a button was pressed
      System.out.println("Edit button pressed"); //test on console
      
      
    } else if (command.equals("Delete")) { //if a button was pressed
      System.out.println("Delete button pressed"); //test on console
      
      int deleteIndex = list.getSelectedIndex();
      
//      System.out.println("Before Delete " + contacts.get(deleteIndex));
      
      //System.out.println("Before Delete " + contacts.get(deleteIndex));
      
      //listModel.removeElement(list.getSelectedValue()); //remove element
      
      listModel.removeElement(list.getSelectedValue()); //remove element
      contacts.remove(deleteIndex);
      
      System.out.println(contacts.get(deleteIndex));
      
      JOptionPane.showMessageDialog (null, "Contact deleted!", "Information", JOptionPane.INFORMATION_MESSAGE);   //dialog box to tell user the contact was deleted  
      
    } else if (command.equals("Save")) { //if a button was pressed
      System.out.println("Save button pressed"); //test on console
      
      //first [numofC] = firstField.getText(); 
      
      
      //listModel.addElement (lastField.getText() + " , " + firstField.getText()); //add last name and the first name onto the list
      listModel.addElement (fullName.getLastName(lastField.getText()) + " , " + fullName.getFirstName(firstField.getText())); //add last name and the first name onto the list
      //listModel.addElement (address.getLastName(unitField.getText()) + " , " + address.getFirstName(streetField.getText()) + " , " + address.getFirstName(cityField.getText()) + " , " + address.getFirstName(postalField.getText()) + " , " + address.getFirstName(stateField.getText()) + " , " + address.getFirstName(countryField.getText())); //add last name and the first name onto the list
      
      //bank.addPenny(); //add contact
      contacts.add(fullName); //add object to arraylist
      contacts.add(address); //add object to arraylist
      contacts.add(info); //add object to arraylist
      
      //print information for contact
      System.out.println("Name: " + fullName.getLastName(lastField.getText()) + " , " + fullName.getFirstName(firstField.getText())); 
      System.out.println("Address: " + unitField.getText() + " " + streetField.getText()  + ", " + cityField.getText() + postalField.getText() + ", " + stateField.getText() + ", " + countryField.getText());
      System.out.println("Phone: " + phoneField.getText());
      System.out.println("Email Address: " + emailField.getText());
      System.out.println("Company: " + companyField.getText());
      System.out.println("Group: ");
      System.out.println("Notes: " + notesArea.getText() + "\n");
      
//      output.println("First Name: ");
//      output.println("Last Name: ");
//      output.println("Address: ");
//      output.println("Phone Number: ");
//      output.println("Email Address: ");
//      output.println("Company: ");
//      output.println("Group: ");
//      output.println("Notes: ");
//      output.close();
      
      //try and catch
      try {
        writeFile(); //CALL WRITE FILE METHOD
      } catch (Exception e) {}
      
      JOptionPane.showMessageDialog (null, "Contact saved!", "Information", JOptionPane.INFORMATION_MESSAGE);   //dialog box to tell user the contact was deleted  
      
    } else if (command.equals("Clear")) { //if a button was pressed
      System.out.println("Clear button pressed"); //test on console
      firstField.setText ("");
      lastField.setText ("");
      unitField.setText ("");
      streetField.setText ("");
      cityField.setText ("");
      stateField.setText ("");
      countryField.setText ("");
      phoneField.setText ("");
      emailField.setText ("");
      companyField.setText ("");
      notesArea.setText ("");
      
      JOptionPane.showMessageDialog (null, "Fields cleared!", "Information", JOptionPane.INFORMATION_MESSAGE);   //dialog box to tell user the contact was deleted  
      
    } else if (command.equals("Clear Search")) { //if a button was pressed
      System.out.println("Clear Search button pressed"); //test on console
      searchField.setText ("");
      
    } else if (command.equals("Search")) { //if a button was pressed
      System.out.println("Search button pressed"); //test on console 
    }
  }
  
  public void writeFile () throws Exception {
    myFile = new File("contacts.txt");
    output = new PrintWriter(myFile); //java.io.PrintWriter class can be used to create a file and write data to a text file 
    
    output.println("First Name: " + firstField.getText());
    output.println("Last Name: " + lastField.getText());
    output.println("Address: " + unitField.getText() + streetField.getText() + ", " + cityField.getText() + postalField.getText() +  ", " + stateField.getText() +  ", " + countryField.getText());
    output.println("Phone Number: " + phoneField.getText());
    output.println("Email Address: " + emailField.getText());
    output.println("Company: " + companyField.getText());
    //output.println("Group: " + groupField.getText());
    output.println("Notes: " + notesArea.getText());
    
    output.close(); //close file
  }
  
  public void readFile () throws Exception {
    input = new Scanner(myFile);
      
    while (input.hasNext()) { // Read data from a file
      String firstName = input.next();
    }
    input.close(); // Close the file
  }
  
  //////////////////////sort names///////////////  
//  public class InsertionSort {
//    public static void main(String args[]) {     
//      int[] arr = {7, 4, 2, 6, 3, 5}; 
//      int j, temp; 
//    
//      for (int i = 1; i < arr.length; i++)  {
//         temp = arr[i] ; 
//         j =  i ;      
// 
//         while (j > 0 && arr[j -� 1] > temp ) {
//            arr[j] = arr[ j -� 1 ]; //swap
//            j -- ;   
//         } // while loop ends
//         arr[j] = temp; //swap
//    } // for loop ends
//  } // main method ends
//} // class ends

  ////////////////////insertion sort////////////////////
//  public static int binarySearch (String[] list, String sName) { 
//    int low = 0, high = list.length - 1;
//    
//    while (low <= high) {
//      System.out.println("Low and High (to be calculated): " + low + " and " + high);
//      
//      int mid = (high + low) / 2;
//      System.out.println("Mid " + mid);
//      
//      if (list[mid].compareTo(sName) == 0) {
//        System.out.println("Found in " + mid);
//        return mid;
//      } else if (list[mid].compareTo(sName) > 0) {
//        high = mid - 1;
//        System.out.println("New high " + high);
//      } else {
//        low = mid + 1;
//        System.out.println("New low " + low);
//      }
//    }
//    return -1; //not found
//  }
  
  
  /////////////////////MAIN METHOD//////////////////////////
//main method -- menu driven application for storing money in a piggy bank
  public static void main(String args[]) throws Exception {  //main method
    AddressBookGUI frame = new AddressBookGUI(); //one line of code to create the frame  
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //when closed it resets interactions
    myScanner.close(); //close Scanner
  } //end main method
} //end class
