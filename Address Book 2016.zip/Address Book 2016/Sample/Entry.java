import java.util.Scanner;
//class Book{

public class Entry {
  
  Scanner s = new Scanner(System.in);
  
  //declare private variables
  private String first;
  private String last;
  private int unit;
  private String street;
  private String city;
  private String postal;
  private String state;
  private String country;
  private String email;
  private String phone;
  private String company;
  private String group;
  private String notes;
  
  Entry (String first, String last, int unit, String street, String city, String postal, String state, String country, String email, String phone, String company, String notes){
    this.first = first;
    this.last = last;
    this.unit = unit;
    this.street = street;
    this.city = city;
    this.postal = postal;
    this.state = state;
    this.country = country;
    this.email = email;
    this.phone = phone;
    this.company = company;
    //this.group = group;
    this.notes = notes;
  }
  
  //initialize fields
  Entry(){
    first = "";
    last = "";
    unit = 0;
    street = "";
    city = "";
    postal = "";
    state = "";
    country = "";
    email = "";
    phone = "";
    company = "";
    notes = "";
  }
  ////////read entries///////////
  public void readEntry(){
    System.out.println("First Name:" + first);
    System.out.println("Last Name:" + last);
    System.out.println("Address:" + unit + " " + street + " " + city + " " + postal + " " + state + " " + country);
    System.out.println("Email:" + email);
    System.out.println("Phone:" + phone);
    System.out.println("Company:" + company);
    System.out.println("Notes:" + notes);
  }
  
//Keeps track of how many entries are in the book
  private int entries = 0;
  Entry[] contents;
  public void initEntries(int e) {
    contents = new Entry[e];
    for (int i = 0; i < contents.length; i++){ //Initializes an array of entries, then loops through to initialize each individual entry
      contents[i] = new Entry();
    }
  }
  
  public int getEntries(){
    return contents.length;
  }
//Adds an entry to the book
  public void add(String first, String last, int unit, String street, String city, String postal, String state, String country, String email, String phone, String company, String notes){
    if (entries<contents.length){
      contents[entries] = new Entry(first, last, unit, street, city, postal, state, country, email, phone, company, notes);
      entries++;
    }
    else System.out.println("Error: book is full");
  }
  
//Removes an entry from the book
  public void remove(int entry){
    if (entries>0){
      contents[entry] = new Entry();
      for (int i = 0;i<entries-entry;i++){
        if (entry+1==entries) contents[entry] = new Entry();
        else{
          Entry temp = contents[entry+i];
          contents[entry+i] = contents[entry+i+1]; //Removes an entry end moves each entry after it one backwards.
          contents[entry+i+1] = temp;
        }
      }
      entries--;
    }
    else System.out.println("Error: book is empty.");
  }
  
//Changes the values of an entry
  public void edit(String first, String last, int unit, String street, String city, String postal, String state, String country, String email, String phone, String company, String notes, int selection){
    contents[selection].first = first;
    contents[selection].last = last;
    contents[selection].unit = unit;
    contents[selection].street = street;
    contents[selection].city = city;
    contents[selection].postal = postal;
    contents[selection].state = state;
    contents[selection].country = country;
  }
  
//Sorts the book based on a part of the entry
//int n is used to tell which part of the entries to base the sort on
  public void sort(int n){
    for(int i = 0;i<contents.length;i++){
      for (int j = 0;j<contents.length;j++){
        switch(n){
          case 1:
            if (contents[i].first.compareTo(contents[j].first)<0){
            Entry temp = contents[i];
            contents[i] = contents[j];
            contents[j] = temp;
          }
            break;
          case 2:
            if (contents[i].last.compareTo(contents[j].last)<0){
            Entry temp = contents[i];
            contents[i] = contents[j];
            contents[j] = temp;
          }
            break;
//          case 3:
//            if (contents[i].email.compareTo(contents[j].email)<0){
//            Entry temp = contents[i];
//            contents[i] = contents[j];
//            contents[j] = temp;
//          }
//            break;
          default: 
            System.out.println("Error: invalid field");
            break;
        }
      }
    }
  }
  public void addFromCopy(Entry e){
    if (entries<contents.length){
      contents[entries] = e;
      entries++;
    }
    else System.out.println("Error: book is full");
  }
}

